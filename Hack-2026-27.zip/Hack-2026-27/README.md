# Hack-2026-27 · Agentic SOC para Tarvia Group

UAB Hackathon 2026 · Reto Deloitte: IA para ciberseguridad.

Sistema de **triaje de alertas asistido por IA**: por cada alerta investiga, reúne evidencias, propone un veredicto
(semáforo 🔴 🟡 🟢), calcula la prioridad con la política del SOC y **deja la decisión final a una persona**.

## Estado real del proyecto (honestidad ante todo)

| Parte | Estado |
|---|---|
| Orquestador de los 7 pasos, política del semáforo, detección de inyección, aprobación de contención, API y dashboard | Escritos. La lógica pura tiene tests que pasan (36). |
| Capa con pydantic / FastAPI / Streamlit | Escrita pero **no ejecutada todavía**: instala dependencias y lanza los tests (ver abajo). |
| Conector con la API real de Deloitte (`HttpSOCClient`) | **Plantilla sin verificar**: endpoints, autenticación y formatos son supuestos hasta leer su documentación. |
| Matriz de severidad, SLA y runbooks (`data/policies/`) | **PLACEHOLDERS inventados**. Hay que sustituirlos por los oficiales. |
| Datos de `data/fixtures/` | **Inventados** para desarrollar. No son datos de Deloitte. |
| `HeuristicJudge` | Línea base determinista **sin IA** para tests. El juez de IA es `AnthropicJudge` (requiere clave y no se ha probado contra el modelo). |
| Umbrales (0,7 de confianza, 0,9 en activos críticos, 2 evidencias para rojo) | Propuestas: calibrar con las 10 alertas reales. |

## Cómo funciona

```
Alerta → [1 Entender] → [2 Contextualizar] → [3 Enriquecer] → [4 Correlacionar]   (código determinista + herramientas de solo lectura)
       → [5 Decidir: el juez propone veredicto + evidencias]                      (único paso con IA)
       → valida que cada evidencia cite un ID realmente recuperado               (anti-invención)
       → política del semáforo (código)  → [6 Priorizar: matriz + SLA] → [7 Actuar: PROPONE]
       → analista: aceptar / corregir / escalar / aprobar contención simulada
```

**Semáforo** (se evalúa primero el amarillo):

- 🟡 **Duda → decide siempre un humano**: fallo o vacío en una consulta obligatoria, evidencias contradictorias,
  afirmaciones sin evidencia, confianza baja, activo crítico ambiguo, posible inyección de instrucciones,
  regla sin runbook. *Nunca* se cierra sola.
- 🔴 **TP**: veredicto TP + ≥ N evidencias verificables + sin cambio autorizado que lo explique.
- 🟢 **FP / BTP**: exige evidencia **positiva** de legitimidad (p. ej. un cambio autorizado). "No encontré nada malo" no basta.

**Control humano**: la IA nunca cierra ni contiene. Una contención exige confirmación explícita y un token firmado (HMAC),
de un solo uso, con caducidad y ligado a alerta + objetivo + operación.

## Instalación y uso

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # rellenar; .env NO se sube a Git

python -m unittest discover -s tests -t . -v           # o: pytest
uvicorn backend.main:app --reload                      # terminal 1 → http://localhost:8000/docs
streamlit run frontend/app.py                          # terminal 2 → dashboard
```

Por defecto usa datos de ejemplo (`SOC_CLIENT_MODE=fixture`) y el juez sin IA (`LLM_MODE=heuristic`).
Para usar el modelo: `LLM_MODE=anthropic` y `ANTHROPIC_API_KEY` en `.env`.

## Qué hacer cuando llegue la documentación de Deloitte

1. `backend/integrations/soc_client.py`: rellenar `ENDPOINTS`, autenticación, paginación y la petición de contención;
   ajustar `ALERT_FIELD_ALIASES`; asegurar que cada registro tenga `id`. Poner `SOC_CLIENT_MODE=http`.
2. `data/policies/severity_matrix.json`: matriz y SLA oficiales (quitar `_placeholder`).
3. `data/policies/runbooks.json`: los 9 runbooks (herramientas obligatorias y contenciones permitidas).
   Valorar `allow_default: false` para que una regla sin runbook vaya a revisión.
4. `data/demo_alerts.txt`: los IDs de las 10 alertas de la demo.
5. Ejecutar las 10 alertas, **revisar a mano cada resultado**, ajustar umbrales y documentar por qué.
6. Medir tiempos reales (`/metrics`); no afirmar porcentajes de mejora sin comparación reproducible.

## Estructura

```
backend/
  integrations/soc_client.py   # Fixture (dev) y Http (plantilla) del conector
  triage/                      # tools · injection · llm (jueces) · investigation (7 pasos) · engine
  policies/                    # traffic_light · severity · runbooks · containment
  models/                      # enums y contrato de salida validado (pydantic)
  review.py · storage.py · main.py (API FastAPI)
frontend/app.py                # dashboard Streamlit
data/fixtures · data/policies  # datos de ejemplo y políticas PLACEHOLDER
tests/
```

## Seguridad

- Datos y sistemas ficticios: no probar ataques ni ejecutar contenciones reales.
- Logs y alertas son **datos no confiables**: pueden contener inyección de instrucciones. Se escanean y se delimitan para el modelo.
- Herramientas de solo lectura; la contención solo se ejecuta tras aprobación humana.
- Nada de secretos en Git (`.env` está en `.gitignore`); del token de aprobación solo se guarda una huella.

## Limitaciones conocidas

- La detección de inyección es por patrones (capa de aviso, no garantía).
- La correlación actual es básica (eventos y alertas que comparten entidades); no hay grafo ni correlación entre alertas.
- Procesamiento secuencial, sin cola ni reintentos de alertas completas.
- El token de aprobación local no sustituye al mecanismo real de Deloitte.
